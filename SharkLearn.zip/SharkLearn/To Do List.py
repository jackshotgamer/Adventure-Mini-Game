# 1. xp: DONE
# 2. stats: DONE
# 3. gold: DONE
# 4. shop: DONE
# 5. weapons: DONE
# 6. enemies: DONE
# 7. loot: DONE
# 8. difficulty: DONE
# 8.1              difficulty scaling: DONE
# 9. leveling: DONE
# 10. Player Globalisation:
# 10.1             Leaderboards:

# take 1: 391 lines of code
# take 2: 227 lines of code
# take 3: 700 lines of code
